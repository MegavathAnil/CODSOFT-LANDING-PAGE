// Simple Express + Socket.IO server to serve the landing page and provide a real-time chat demo.
const express = require('express');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Serve static files from the landing page folder
app.use(express.static(path.join(__dirname)));

app.get('/api/status', (req, res) => {
  res.json({status: 'ok', time: new Date().toISOString()});
});

io.on('connection', (socket) => {
  console.log('socket connected:', socket.id);
  socket.emit('system', 'Welcome! You are connected.');
  socket.broadcast.emit('system', 'A user joined the chat.');

  socket.on('join', (data) => {
    console.log('join', data);
  });

  socket.on('message', (msg) => {
    console.log('message', msg);
    // broadcast to others
    socket.broadcast.emit('message', {from: socket.id.slice(0,6), text: msg.text});
  });

  socket.on('disconnect', () => {
    console.log('socket disconnected:', socket.id);
    socket.broadcast.emit('system', 'A user left the chat.');
  });
});

server.listen(PORT, () => {
  console.log('Server listening on http://localhost:' + PORT);
});
