# Landing Page — Development

Quick steps to run a live-reloading dev server for this static landing page on Windows (PowerShell):

Option A — using npx (no install):

```powershell
cd 'c:\CODSOFT\LANDING PAGE'
# start live-server via npx
npx live-server --port=3000 --open=./index.html
```

Option B — using npm (install once):

```powershell
cd 'c:\CODSOFT\LANDING PAGE'
npm install
npm start
```

Option C — using Python 3 (no live reload):

```powershell
cd 'c:\CODSOFT\LANDING PAGE'
python -m http.server 3000
# then open http://localhost:3000 in your browser
```

Option D — VS Code Live Server extension:
- Install the Live Server extension and open the folder in VS Code.
- Right-click `index.html` and choose "Open with Live Server".

Notes:
- `live-server` provides hot reload for HTML/CSS changes.
- If you prefer another dev server (Browsersync, Vite), I can add a config.
